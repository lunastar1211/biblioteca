const form = document.getElementById('login-form');
const btn = document.getElementById('btn-ircadastro');

form.addEventListener('submit', e=>{
    e.preventDefault();

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const perfil = document.querySelector('input[name="perfil"]:checked').value;

    console.log(perfil);

    loginUsuario(email, senha, perfil);
})

btn.addEventListener('click', function(){
    window.location.href = '/index.html'
});

function loginUsuario(email, senha, perfil) {
    fetch('/api/usuarios/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            email,
            senha,
            perfil
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.sucesso) {
            if (perfil === 'leitor') {
                window.location.href = '/leitor.html';
            } else {
                window.location.href = '/bibliotecario.html';
            }
        } else {
            alert('Email ou senha incorretos');
        }
    });
}