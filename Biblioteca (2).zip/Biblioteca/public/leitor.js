const tabelaLivros = document.getElementById('tabela-livros');
const tabelaEmprestimos = document.getElementById('tabela-emprestimos');

fetch('/api/livros')
    .then(res => res.json())
    .then(livros => {

        livros.forEach(livro => {

            const linha = document.createElement('tr');

            linha.innerHTML = `
                <td>${livro.id}</td>
                <td>${livro.titulo}</td>
                <td>${livro.autor}</td>
                <td>${livro.ano_publicacao}</td>
                <td>${livro.quantidade_disponivel}</td>
                <td>
    <button onclick="solicitarEmprestimo(${livro.id})">
        Solicitar Empréstimo
    </button>
</td>
            `;

            tabelaLivros.appendChild(linha);
        });
    });

fetch('/api/emprestimos')
    .then(res => res.json())
    .then(emprestimos => {

        emprestimos.forEach(emp => {

            const linha = document.createElement('tr');

            const data = new Date(emp.data_devolucao_prevista);

            linha.innerHTML = `
        <td>${emp.titulo}</td>
        <td>${data.toLocaleDateString('pt-BR')}</td>
        <td>${emp.status}</td>
        <td>
    <button onclick="solicitarDevolucao(${emp.id})">
    Solicitar Devolução
</button>
</td>
    `;

            tabelaEmprestimos.appendChild(linha);
        });
    });

function solicitarEmprestimo(livroId) {

    const hoje = new Date();

    const devolucao = new Date();
    devolucao.setDate(hoje.getDate() + 7);

    fetch('/api/emprestimos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            livro_id: livroId,
            leitor_id: 1, // usuário de teste
            data_emprestimo: hoje.toISOString().split('T')[0],
            data_devolucao_prevista: devolucao.toISOString().split('T')[0],
            status: 'ativo'
        })
    })
        .then(() => {
            alert('Empréstimo solicitado com sucesso!');
            location.reload();
        });
}

function solicitarDevolucao(id) {

    fetch(`/api/emprestimos/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            data_devolucao_real: null,
            status: 'ativo'
        })
    })
        .then(() => {
            alert('Devolução solicitada!');
            location.reload();
        });
}