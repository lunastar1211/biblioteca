const form = document.getElementById('cadastro-form');
const btn = document.getElementById('btn-irlogin');

form.addEventListener('submit', e =>{
    e.preventDefault();

    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const perfil = document.querySelector('input[name="perfil"]:checked').value;

    console.log(perfil);

    cadastrarUsuario(nome, email, senha, perfil);
});

btn.addEventListener('click', function(){
    window.location.href = '/login.html'
});


function cadastrarUsuario(nome, email, senha, perfil){
    fetch('/api/usuarios', {
        method: 'POST',
        headers: { 'Content-type': 'application/json'},
        body: JSON.stringify({nome, email, senha, perfil})
    })
    .then(() =>{
        form.reset();

        if (perfil === 'leitor') {
        window.location.href = '/leitor.html';
    } else {
        window.location.href = '/bibliotecario.html';
    }
    });
};


