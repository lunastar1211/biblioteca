const listaLivro = document.getElementById('lista-livros');

const form = document.getElementById('adc-livros');

const listaEmprestimos = document.getElementById('lista-usuario');

const btn = document.getElementById('btn-irlogin');

const btn2 = document.getElementById('devolve');

carregarLista();

btn.addEventListener('click', function(){
    window.location.href = '/login.html'
});


form.addEventListener('submit', e =>{
    e.preventDefault();

    const titulo = document.getElementById('titulo').value;
    const autor = document.getElementById('autor').value;
    const ano = document.getElementById('ano').value;
    const qnt = document.getElementById('qnt').value;

    adicionarLivro(titulo, autor, ano, qnt);
});

function adicionarLivro(titulo, autor, ano, qnt){
    fetch('/api/livros', {
        method: 'POST',
        headers: { 'Content-type': 'application/json'},
        body: JSON.stringify({titulo, autor, ano_publicacao : ano, quantidade_disponivel: qnt})
    })
    .then(() =>{
        form.reset();
        carregarLista();
    })
}

function carregarLista(){
    fetch('/api/livros')
    .then(res => res.json())
    .then(data => {
        listaLivro.innerHTML = '';
        data.forEach(livro =>{
            const li = document.createElement('li');
            li.innerHTML = `${livro.id} ${livro.titulo} ${livro.autor} ${livro.ano_publicacao} (${livro.quantidade_disponivel})
            <button onclick ="atualizarLivro(${livro.id})">Editar</button>
            <button onclick ="excluirLivro(${livro.id})">Excluir</button>`
            listaLivro.appendChild(li);
        })
    })
}


function atualizarLivro(id){
    const titulo = prompt('Digite o novo titulo: ');
    const autor = prompt('Digite o novo autor: ');
    const ano = prompt('Digite o novo ano de publicação: ');
    const qnt = prompt('Digite a nova quantidade de livros: ');
    fetch(`/api/livros/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ titulo, autor, ano_publicacao : ano, quantidade_disponivel: qnt }) 
    })
    .then(() =>{
        carregarLista();
    })
}

function excluirLivro(id){
    const confirmacao = confirm('Tem certeza maluco?');

    if(!confirmacao){
        return;
    };

    fetch(`/api/livros/${id}`, {
        method: 'DELETE'
    })
    .then(() =>{
        carregarLista();
    });
};

fetch('/api/emprestimos')
.then(res => res.json())
.then(data => {

    listaEmprestimos.innerHTML = '';

    data
        .filter(emp => emp.status === 'ativo')
        .forEach(emp => {

            const li = document.createElement('li');

            li.innerHTML = `
                ${emp.nome}
                - ${emp.titulo}
                - ${emp.data_emprestimo}
                - ${emp.data_devolucao_prevista}

                <button onclick="aprovarDevolucao(${emp.id})">
                    Aprovar Devolução
                </button>
            `;

            listaEmprestimos.appendChild(li);
        });
});

function aprovarDevolucao(id){

    fetch(`/api/emprestimos/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            data_devolucao_real: new Date().toISOString().split('T')[0],
            status: 'devolvido'
        })
    })
    .then(() => {
        alert('Devolução feita!');
        location.reload();
    });

}