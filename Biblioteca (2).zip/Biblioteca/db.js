const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'alicefofa14',
    database: 'biblioteca',
    port: '3306'
});

db.connect(err =>{
    if(err) throw err;
    console.log('conectado ao banco de daods');
});

module.exports = db;
