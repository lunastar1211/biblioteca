const express = require('express');

const router = express.Router();

const db = require('../db');


router.post('/', (req, res) => {
    const {
        livro_id,
        leitor_id,
        data_emprestimo,
        data_devolucao_prevista,
        status
    } = req.body;

    db.query(
        `INSERT INTO emprestimos
        (livro_id, leitor_id, data_emprestimo, data_devolucao_prevista, status)
        VALUES (?, ?, ?, ?, ?)`,
        [livro_id, leitor_id, data_emprestimo, data_devolucao_prevista, status],
        (err, result) => {
            if (err) return res.status(500).send(err);

            db.query(
                'UPDATE livros SET quantidade_disponivel = quantidade_disponivel - 1 WHERE id = ?',
                [livro_id]
            );
            res.status(201).json({
                id: result.insertId,
                livro_id,
                leitor_id,
                data_emprestimo,
                data_devolucao_prevista,
                status
            });
        }
    );
});

router.put('/:id', (req, res) => {
    const { id } = req.params;

    const {
        data_devolucao_real,
        status
    } = req.body;

    db.query(
        'UPDATE emprestimos SET data_devolucao_real = ?, status = ? WHERE id = ?',
        [data_devolucao_real, status, id],
        (err) => {
            if (err) return res.status(500).send(err);

            res.json({
                id,
                data_devolucao_real,
                status
            });
        }
    );
});


router.delete('/:id', (req, res) => {
    const { id } = req.params;

    db.query(
        'DELETE FROM emprestimos WHERE id = ?',
        [id],
        (err) => {
            if (err) return res.status(500).send(err);

            res.sendStatus(204);
        }
    );
});

router.get('/', (req, res) => {
    db.query(`
        SELECT
            e.id,
            u.nome,
            l.titulo,
            e.data_emprestimo,
            e.data_devolucao_prevista,
            e.status
        FROM emprestimos e
        JOIN usuarios u ON e.leitor_id = u.id
        JOIN livros l ON e.livro_id = l.id
    `,
        (err, results) => {
            if (err) return res.status(500).send(err);
            res.json(results);
        });
});

router.put('/:id', (req, res) => {

    const { id } = req.params;
    const { status, data_devolucao_real } = req.body;

    db.query(
        `UPDATE emprestimos
         SET status = ?, data_devolucao_real = ?
         WHERE id = ?`,
        [status, data_devolucao_real, id],
        (err) => {

            if (err) return res.status(500).send(err);

            res.json({
                mensagem: 'Empréstimo atualizado'
            });
        }
    );
});



module.exports = router;