const express = require('express');

const router = express.Router();

const db = require('../db');

router.post('/', (req, res)=>{
    const {nome, email, senha, perfil} = req.body;
    console.log('POST /api/usuarios chegou');

    db.query('INSERT INTO usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)', [nome, email, senha, perfil],
        (err, result) => {
            console.log('Callback do MySQL executou');
            if(err) return res.status(500).send(err);
            res.status(201).json({id:result.insertId, nome, email, senha, perfil});
        }
    );
})

router.post('/login', (req, res) => {

    const { email, senha, perfil } = req.body;

    db.query(
        'SELECT * FROM usuarios WHERE email = ? AND senha = ?',
        [email, senha],
        (err, results) => {

            if (err) {
                return res.status(500).send(err);
            }

            if (results.length > 0) {
                return res.json({ sucesso: true });
            }

            res.json({ sucesso: false });
        }
    );
});

router.get('/', (req,res) =>{
    db.query('SELECT * FROM usuarios', (err, results) =>{
        if(err) return res.status(500).send(err);
        res.json(results);
    });
});

router.put('/:id', (req,res) =>{
    
    const {nome, email, perfil} = req.body;
    const {id} = req.params;

    db.query('UPDATE usuarios SET nome = ?, email = ?, perfil = ? WHERE id = ?', [nome, email, perfil, id], (err) =>{
        if(err) return res.status(500).send(err);
        res.json({id, nome, email, perfil});
    });
});

router.delete('/:id', (req, res) => {

    const {id} = req.params;

    db.query('DELETE FROM usuarios WHERE id = ?', [id], (err) => {
        if(err) return res.status(500).send(err);
        res.sendStatus(204);
    });
});

module.exports = router;
