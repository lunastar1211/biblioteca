const express = require('express');
const app = express()
const port = 3000

const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));

const db = require('./db');


app.get('/', (req, res) => {
  //res.send('Hello World!')
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
})

const usuariosRoutes = require('./routes/usuarios');
const livrosRoutes = require('./routes/livros');
const emprestimosRoutes = require('./routes/emprestimos');

app.use(express.json());

app.use('/api/usuarios', usuariosRoutes);
app.use('/api/livros', livrosRoutes);
app.use('/api/emprestimos', emprestimosRoutes);



app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
